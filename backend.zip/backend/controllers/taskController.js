const Task = require("../models/Task");
const Topic = require("../models/Topic");

exports.createTask = async (req, res) => {

    try {

        const { title, topic } = req.body;

        const task = new Task({

            title,
            topic,
            createdBy: req.user.id

        });

        await task.save();

        res.status(201).json({

            message: "Task Created",
            task

        });

    }

    catch(error) {

        console.log(error);

        res.status(500).json({
            message: "Something went wrong"
        });

    }

};

exports.getTasks = async (req, res) => {

    try {

        const tasks = await Task.find({

            topic: req.params.topicId,
            createdBy: req.user.id

        });

        res.json(tasks);

    }

    catch(error) {

        console.log(error);

        res.status(500).json({

            message: "Something went wrong"

        });

    }

};


exports.updateTask = async (req, res) => {

     try {

        const task = await Task.findOneAndUpdate(

            {
                _id: req.params.id,
                createdBy: req.user.id
            },

            {
                completed: req.body.completed
            },

            {
                new: true
            }

        );

        if (!task) {
            return res.status(404).json({
                message: "Task not found"
            });
        }

        const totalTasks = await Task.countDocuments({
            topic: task.topic
        });

        const completedTasks = await Task.countDocuments({
            topic: task.topic,
            completed: true
        });

        const progress = Math.round((completedTasks / totalTasks) * 100);

        await Topic.findByIdAndUpdate(task.topic, {
            progress: progress
        });

        res.json({
            message: "Task updated successfully",
            task,
            progress
        });

    } catch (error) {

        console.log(error);

        res.status(500).json({
            message: "Something went wrong"
        });

    }

};


exports.deleteTask = async (req, res) => {

    try {

        await Task.findOneAndDelete({

            _id: req.params.id,
            createdBy: req.user.id

        });

        res.json({

            message: "Task Deleted"

        });

    }

    catch(error) {

        console.log(error);

        res.status(500).json({

            message: "Something went wrong"

        });

    }

};