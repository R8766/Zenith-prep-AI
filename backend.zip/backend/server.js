const express = require("express");
const connectDB = require("./config/db");

const cors = require("cors");

const authRoutes = require("./routes/authRoutes");
const topicRoutes = require("./routes/topicRoutes");
const taskRoutes = require("./routes/taskRoutes");
const dashboardRoutes = require("./routes/dashboardRoutes");

const app = express();

app.use(cors());

connectDB();

app.use(express.json());

app.use(topicRoutes);
app.use(authRoutes);
app.use(taskRoutes);
app.use(dashboardRoutes);

app.get("/", (req, res) => {
    res.send("Hello Backend");
});


app.listen(5000, () => {
    console.log("Server is running on port 5000");
});